# AIpromptfromabdul.com — Full-stack website

Includes:
- Responsive black-and-gold website (`index.html`)
- Admin panel (`/admin.html`) to add, edit and delete published prompts
- Public prompt library visible to all visitors
- Email delivery endpoint so visitors request a prompt using their email address
- JSON-backed prompt storage, Express server, basic email request throttling

## Run locally

Requires Node.js 18+.

1. Install dependencies:
   ```bash
   npm install
   ```
2. Copy `.env.example` to `.env` and fill in values.
3. Export the variables from `.env` in your terminal (or use your hosting provider's environment-variable settings). This project intentionally does not load `.env` automatically.
4. Start:
   ```bash
   npm start
   ```
5. Open `http://localhost:3000`. Admin: `http://localhost:3000/admin.html`.

## Required email setup

Prompt delivery uses Resend's email API. Create a Resend account, verify a domain you control, create an API key, and set:
- `RESEND_API_KEY`
- `FROM_EMAIL` to an address on the verified domain

Do not commit API keys or passwords into source code. The email sender will return a configuration error until these values are set. Test delivery before sharing the website publicly.

## Deployment

Deploy this folder to a Node.js host that supports Node 18+. Set the environment variables in the host dashboard. Configure persistent storage and set `DATA_DIR` to that mounted disk path; otherwise prompt JSON data may be lost on redeploy/restart depending on the host. Add your domain in the hosting provider and configure DNS as instructed by that provider.

## Important limitations / production hardening

- Prompts are public by design; do not publish private or copyrighted material without permission.
- This starter stores prompts in a JSON file. For a larger production site or multiple server instances, replace it with a managed database.
- Basic email throttling is in-memory and resets on server restart; production deployments should use durable rate limiting, bot protection, and email verification/abuse controls.
- The public contact form currently opens the visitor's email app; it is not a server-side contact inbox.
