const http = require('http');
const express = require('express');
const crypto = require('crypto');
const fs = require('fs');
const path = require('path');

const app = express();
const PORT = process.env.PORT || 3000;
const DATA_DIR = process.env.DATA_DIR || path.join(__dirname, 'data');
const DB_FILE = path.join(DATA_DIR, 'prompts.json');
const ADMIN_PASSWORD = process.env.ADMIN_PASSWORD;
const SESSION_SECRET = process.env.SESSION_SECRET;
const RESEND_API_KEY = process.env.RESEND_API_KEY;
const FROM_EMAIL = process.env.FROM_EMAIL;
const SITE_NAME = 'AIpromptfromabdul.com';

if (!ADMIN_PASSWORD || !SESSION_SECRET) {
  console.error('Missing required environment variables: ADMIN_PASSWORD and SESSION_SECRET.');
  process.exit(1);
}
fs.mkdirSync(DATA_DIR, { recursive: true });
if (!fs.existsSync(DB_FILE)) fs.writeFileSync(DB_FILE, '[]', { mode: 0o600 });
app.disable('x-powered-by');
app.use(express.json({ limit: '30kb' }));
app.use(express.static(__dirname, { index: 'index.html' }));

function readPrompts() { try { return JSON.parse(fs.readFileSync(DB_FILE, 'utf8')); } catch { return []; } }
function writePrompts(items) { fs.writeFileSync(DB_FILE, JSON.stringify(items, null, 2), { mode: 0o600 }); }
function safeEqual(a, b) {
  const aa = Buffer.from(String(a || '')); const bb = Buffer.from(String(b || ''));
  return aa.length === bb.length && crypto.timingSafeEqual(aa, bb);
}
function sign(value) { return crypto.createHmac('sha256', SESSION_SECRET).update(value).digest('hex'); }
function setSession(res) {
  const value = crypto.randomBytes(32).toString('hex');
  const token = value + '.' + sign(value);
  res.setHeader('Set-Cookie', `abdul_admin=${token}; HttpOnly; SameSite=Lax; Path=/; Max-Age=28800${process.env.NODE_ENV === 'production' ? '; Secure' : ''}`);
}
function clearSession(res) { res.setHeader('Set-Cookie', 'abdul_admin=; HttpOnly; SameSite=Lax; Path=/; Max-Age=0'); }
function isAdmin(req) {
  const raw = (req.headers.cookie || '').split(';').map(x => x.trim()).find(x => x.startsWith('abdul_admin='));
  if (!raw) return false;
  const token = decodeURIComponent(raw.slice('abdul_admin='.length));
  const parts = token.split('.');
  return parts.length === 2 && safeEqual(parts[1], sign(parts[0]));
}
function requireAdmin(req, res, next) { if (!isAdmin(req)) return res.status(401).json({ error: 'Please sign in as admin.' }); next(); }
function cleanString(value, max) { return typeof value === 'string' ? value.trim().slice(0, max) : ''; }

app.get('/api/health', (_req, res) => res.json({ ok: true }));
app.get('/api/prompts', (_req, res) => {
  const items = readPrompts().sort((a,b) => b.createdAt.localeCompare(a.createdAt));
  res.set('Cache-Control', 'no-store');
  res.json(items.map(({ id, title, category, body, createdAt }) => ({ id, title, category, body, createdAt })));
});
app.post('/api/admin/login', (req, res) => {
  if (!safeEqual(req.body && req.body.password, ADMIN_PASSWORD)) return res.status(401).json({ error: 'Incorrect password.' });
  setSession(res); res.json({ ok: true });
});
app.get('/api/admin/me', requireAdmin, (_req, res) => res.json({ ok: true }));
app.post('/api/admin/logout', requireAdmin, (_req, res) => { clearSession(res); res.json({ ok: true }); });
app.get('/api/admin/prompts', requireAdmin, (_req, res) => res.json(readPrompts()));
app.post('/api/admin/prompts', requireAdmin, (req, res) => {
  const title = cleanString(req.body.title, 100), category = cleanString(req.body.category, 40) || 'Other', body = cleanString(req.body.body, 10000);
  if (!title || !body) return res.status(400).json({ error: 'Title and prompt text are required.' });
  const items = readPrompts(); const item = { id: crypto.randomUUID(), title, category, body, createdAt: new Date().toISOString() };
  items.push(item); writePrompts(items); res.status(201).json(item);
});
app.put('/api/admin/prompts/:id', requireAdmin, (req, res) => {
  const items = readPrompts(), i = items.findIndex(x => x.id === req.params.id);
  if (i < 0) return res.status(404).json({ error: 'Prompt not found.' });
  const title = cleanString(req.body.title, 100), category = cleanString(req.body.category, 40) || 'Other', body = cleanString(req.body.body, 10000);
  if (!title || !body) return res.status(400).json({ error: 'Title and prompt text are required.' });
  items[i] = { ...items[i], title, category, body, updatedAt: new Date().toISOString() }; writePrompts(items); res.json(items[i]);
});
app.delete('/api/admin/prompts/:id', requireAdmin, (req, res) => {
  const items = readPrompts(), next = items.filter(x => x.id !== req.params.id);
  if (items.length === next.length) return res.status(404).json({ error: 'Prompt not found.' });
  writePrompts(next); res.json({ ok: true });
});

// Basic in-memory request throttling to discourage repeated email requests.
const mailRequests = new Map();
function rateLimitEmail(req, res, next) {
  const ip = req.headers['x-forwarded-for']?.split(',')[0]?.trim() || req.socket.remoteAddress || 'unknown';
  const now = Date.now(), previous = mailRequests.get(ip) || [];
  const recent = previous.filter(t => now - t < 60 * 60 * 1000);
  if (recent.length >= 8) return res.status(429).json({ error: 'Too many requests from this connection. Please try again later.' });
  recent.push(now); mailRequests.set(ip, recent); next();
}
app.post('/api/send-prompt', rateLimitEmail, async (req, res) => {
  const promptId = cleanString(req.body.promptId, 100);
  const email = cleanString(req.body.email, 254);
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) return res.status(400).json({ error: 'Please enter a valid email address.' });
  const prompt = readPrompts().find(x => x.id === promptId);
  if (!prompt) return res.status(404).json({ error: 'That prompt is no longer available. Refresh the page and try again.' });
  if (!RESEND_API_KEY || !FROM_EMAIL) return res.status(503).json({ error: 'Email delivery is not configured yet. The site owner needs to set the email service keys.' });
  const html = `<div style="font-family:Arial,sans-serif;max-width:680px;margin:auto;color:#202020"><div style="background:#080808;color:#f4c84f;padding:22px;border-radius:12px 12px 0 0"><h1 style="margin:0;font-size:22px">${escapeHtml(SITE_NAME)}</h1><p style="margin-bottom:0;color:#fff">Your requested AI prompt</p></div><div style="padding:24px;border:1px solid #ddd;border-top:0"><p>Hello,</p><p>Here is the prompt you requested: <strong>${escapeHtml(prompt.title)}</strong></p><pre style="white-space:pre-wrap;overflow-wrap:anywhere;background:#f6f6f6;border:1px solid #ddd;border-radius:8px;padding:16px;font:14px/1.6 Arial,sans-serif">${escapeHtml(prompt.body)}</pre><p style="color:#666;font-size:12px">You received this email because you requested this prompt on ${SITE_NAME}.</p></div></div>`;
  try {
    const response = await fetch('https://api.resend.com/emails', {
      method: 'POST',
      headers: { 'Authorization': `Bearer ${RESEND_API_KEY}`, 'Content-Type': 'application/json' },
      body: JSON.stringify({ from: `${SITE_NAME} <${FROM_EMAIL}>`, to: [email], subject: `Your AI prompt: ${prompt.title}`, html, text: `Your requested prompt: ${prompt.title}\n\n${prompt.body}\n\nYou received this because you requested this prompt on ${SITE_NAME}.` })
    });
    if (!response.ok) {
      const err = await response.json().catch(() => ({}));
      console.error('Email provider error:', response.status, err);
      return res.status(502).json({ error: 'Email could not be sent right now. Please try again later.' });
    }
    return res.json({ ok: true });
  } catch (err) {
    console.error('Email sending failed:', err.message);
    return res.status(502).json({ error: 'Email service is temporarily unavailable.' });
  }
});
function escapeHtml(value) {
  return String(value).replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
}
app.get('/admin', (_req, res) => res.redirect('/admin.html'));
app.use((err, _req, res, _next) => { console.error(err); res.status(400).json({ error: 'Invalid request.' }); });
app.listen(PORT, () => console.log(`${SITE_NAME} server listening on port ${PORT}`));
